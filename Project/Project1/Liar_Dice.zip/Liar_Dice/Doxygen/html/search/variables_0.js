var searchData=
[
  ['dices',['dices',['../struct_player.html#ac556a9562ee7ee1fcb5fbc9260c383b6',1,'Player']]]
];
