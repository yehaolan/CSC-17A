var indexSectionsWithContent =
{
  0: "abcdgmoprw",
  1: "p",
  2: "mp",
  3: "abcdgmrw",
  4: "do"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables"
};

