var searchData=
[
  ['player',['Player',['../struct_player.html',1,'']]]
];
