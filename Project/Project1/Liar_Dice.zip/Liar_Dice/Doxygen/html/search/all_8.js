var searchData=
[
  ['rdfile',['rdFile',['../main_8cpp.html#a3c08c839bf68fee15983106026558d1d',1,'main.cpp']]],
  ['result',['result',['../main_8cpp.html#a29e77a4cfb880e169516e81bae7473fa',1,'main.cpp']]],
  ['roldice',['rolDice',['../main_8cpp.html#aaa994984d2b7f2720a592eb4746a653d',1,'main.cpp']]]
];
