var searchData=
[
  ['dices',['dices',['../struct_player.html#ac556a9562ee7ee1fcb5fbc9260c383b6',1,'Player']]],
  ['dspdice',['dspDice',['../main_8cpp.html#ab3b58ffea7331c81c06b6473d3a3d5c6',1,'main.cpp']]]
];
