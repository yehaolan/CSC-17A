var searchData=
[
  ['bid',['bid',['../main_8cpp.html#a550b7cb15ebb137e97cc98a6738becc0',1,'main.cpp']]]
];
