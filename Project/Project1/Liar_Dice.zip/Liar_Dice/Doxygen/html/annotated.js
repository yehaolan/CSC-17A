var annotated =
[
    [ "Player", "struct_player.html", "struct_player" ]
];