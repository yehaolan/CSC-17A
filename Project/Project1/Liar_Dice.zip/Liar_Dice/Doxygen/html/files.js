var files =
[
    [ "build", "dir_4fef79e7177ba769987a8da36c892c5f.html", "dir_4fef79e7177ba769987a8da36c892c5f" ],
    [ ".dep.inc", "_8dep_8inc.html", null ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "Player.h", "_player_8h.html", [
      [ "Player", "struct_player.html", "struct_player" ]
    ] ]
];