var struct_player =
[
    [ "dices", "struct_player.html#ac556a9562ee7ee1fcb5fbc9260c383b6", null ],
    [ "order", "struct_player.html#a4c5726c0fa6d1e409a03a0ed2a5d765c", null ]
];