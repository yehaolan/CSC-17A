/* 
 * File:   AbsPlayer.h
 * Author: admin
 *
 * Created on June 5, 2015, 2:31 PM
 */

#ifndef ABSPLAYER_H
#define	ABSPLAYER_H

class AbsPlayer {
    public:
        virtual void bid()=0;
        virtual void chalng()=0;
};

#endif	/* ABSPLAYER_H */

