/* 
 * File:   main.cpp
 * Author: Haolan Ye (Benjamin)
 * Created on May 11, 2015, 10:33 PM
 * Purpose:Homework assignment4
 */

//Library includes Here!!!
#include <iostream>
using namespace std;

//Global Constants Here!!!


//Function prototypes
void pg1();//Gaddis_8thEd_Chap13_ProgChal1
void pg2();//Gaddis_8thEd_Chap13_ProgChal4
void pg3();//Gaddis_8thEd_Chap13_ProgChal5
void pg4();//Gaddis_8thEd_Chap13_ProgChal6
void pg5();//Gaddis_8thEd_Chap13_ProgChal11
void pg6();//Gaddis_8thEd_Chap14_ProgChal1
void pg7();//Gaddis_8thEd_Chap14_ProgChal2
void pg8();//Gaddis_8thEd_Chap14_ProgChal3
void pg9();//Gaddis_8thEd_Chap14_ProgChal4
void pg10();//Gaddis_8thEd_Chap14_ProgChal9

//Begin Execution Here!!!
int main(int argv,char *argc[]){
    //declare variables
    string ans;
    int sel;
    do {    
        cout<<"**************Program Menu**************"<<endl;
        cout<<"1.  13.1"<<endl;
        cout<<"2.  13.4"<<endl;
        cout<<"3.  13.5"<<endl;
        cout<<"4.  13.6"<<endl;
        cout<<"5.  13.11"<<endl;
        cout<<"6.  14.1"<<endl;
        cout<<"7.  14.2"<<endl;
        cout<<"8.  14.3"<<endl;
        cout<<"9.  14.4"<<endl;
        cout<<"10. 14.9"<<endl;
        cout<<"0.Exit the program"<<endl;
        //select program
        bool invalid;
        do {
            invalid=false;
            cout<<"Please select the program(0 to 10)"<<endl;
            cin>>ans;
            if(ans.length()>2) {
                invalid=true;
                cout<<"Invalid input"<<endl;
            }
            if(ans.length()==1) {
                if(ans.at(0)<48||ans.at(0)>57) {
                    cout<<"Invalid input"<<endl;
                    invalid=true;
                }
            }
            if(ans.length()==2) {
                if(ans!="10") {
                    cout<<"Invalid input"<<endl;
                    invalid=true;
                }
            }
        }while(invalid);
        if(ans.length()==1) sel=static_cast<int>(ans.at(0)-48);
        if(ans.length()==2) sel=10;
        switch(sel) {
            case 1: pg1(); break;
            case 2: pg2(); break;
            case 3: pg3(); break;
            case 4: pg4(); break;
            case 5: pg5(); break;
            case 6: pg6(); break;
            case 7: pg7(); break;
            case 8: pg8(); break;
            case 9: pg9(); break;
            case 10: pg10(); break;
            case 0: {
                cout<<"This is the end of the program"<<endl;
                break;
            }
            default:;
        }
        if(sel!=0) {
            cout<<endl<<endl;
            cout<<"Press Enter to continue"<<endl;
            cin.ignore();
        }
    }while(sel!=0);
    return 0;//If midterm not perfect, return something other than 1
}





void pg1(){
        cout<<"In pg # 1"<<endl<<endl;
}

void pg2(){
        cout<<"In pg # 2"<<endl<<endl;
}

void pg3(){
        cout<<"In pg # 3"<<endl<<endl;
}

void pg4(){
        cout<<"In pg # 4"<<endl<<endl;
}

void pg5(){
        cout<<"In pg # 5"<<endl<<endl;
}

void pg6(){
        cout<<"In pg # 6"<<endl<<endl;
}

void pg7(){
        cout<<"In pg # 7"<<endl<<endl;
}

void pg8(){
        cout<<"In pg # 8"<<endl<<endl;
}
void pg9(){
        cout<<"In pg # 9"<<endl<<endl;
}

void pg10(){
        cout<<"In pg # 10"<<endl<<endl;
}