/* 
 * File:   speakers.h
 * Author: admin
 *
 * Created on March 29, 2015, 5:54 PM
 */

#ifndef SPEAKERS_H
#define	SPEAKERS_H

//information of speaker
struct Speaker {
    string name;
    string number;//phone number
    string speTopc;//speaking topic
    int fee;//fee required
};

#endif	/* SPEAKERS_H */

