/* 
 * File:   Class.h
 * Author: admin
 *
 * Created on April 1, 2015, 10:56 PM
 */

#ifndef CLASS_H
#define	CLASS_H

struct Student {
    string name;//student name
    string id;//student id
    int *score;//pointer to an array of scores
    float ave;//average of score
    char grade;//course grade
};

#endif	/* CLASS_H */

