/* 
 * File:   Weather.h
 * Author: admin
 *
 * Created on March 30, 2015, 11:25 AM
 */

#ifndef WEATHER_H
#define	WEATHER_H

struct Weather {
    int totRain;//total rainfall
    int hTemp;//high temperature
    int lTemp;//low temperature
    float aveTemp;//average temperature
};

#endif	/* WEATHER_H */

