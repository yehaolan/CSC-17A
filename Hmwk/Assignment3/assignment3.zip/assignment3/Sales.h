/* 
 * File:   Sales.h
 * Author: admin
 *
 * Created on April 3, 2015, 12:54 AM
 */

#ifndef SALES_H
#define	SALES_H

struct Sales {
    string name;
    int quarter;
    int qrtSale;
};

#endif	/* SALES_H */

