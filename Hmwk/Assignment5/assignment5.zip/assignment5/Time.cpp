/* 
 * File:   Time.cpp
 * Author: Haolan Ye (Benjamin)
 * Created on May 21, 2015, 3:49 PM
 * Purpose: About time
 */


#include "Time.h"

//Constructor
Time::Time(int h, int m, int s) {
    hour=h;
    min=m;
    sec=s;
}

